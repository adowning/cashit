<script setup lang="ts">
  // const { isMobile } = useMonitor()
  // const eventBus = useEventManager()
  // const settingsModal = ref(false)
  // const gameStore = useGameStore()
  // const { gameSearchList } = storeToRefs(gameStore)

  // eventBus.on('settingsModal', (val) => {
  //   console.log('x')
  //   settingsModal.value = val
  // })
</script>
<template>
  <TournamentList />
  <!-- <Vip /> -->
</template>
<style scoped></style>
