/// <reference types="vite-plugin-app-loading/client" />
