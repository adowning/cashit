<template>
    <svg width="16" height="15" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M3.85167 8.41955L6.81332 11.2805L5.62916 12.4246L6.815 13.5695L5.63 14.7136L3.55583 12.711L1.185 15L0 13.8559L2.37084 11.5662L0.296669 9.56443L1.48167 8.42036L2.66667 9.56362L3.85083 8.41955H3.85167ZM0.457574 0L3.42929 0.00242733L13.3325 9.56443L14.5183 8.42036L15.7033 9.56443L13.63 11.567L16 13.8559L14.815 15L12.4442 12.711L10.37 14.7136L9.185 13.5695L10.37 12.4246L0.460088 2.85695L0.457574 0ZM12.5732 0L15.5424 0.00242733L15.5441 2.8529L12.1475 6.1314L9.18416 3.27121L12.5732 0Z" fill="url(#icon-duels-gradient-1)"/>
        <defs>
            <linearGradient id="icon-duels-gradient-1" x1="16.0259" y1="2.79568e-07" x2="-2.64734" y2="4.88932" gradientUnits="userSpaceOnUse">
                <stop stop-color="#d15e5e"/>
                <stop offset="1" stop-color="#ff4545"/>
            </linearGradient>
        </defs>
    </svg>
</template>
