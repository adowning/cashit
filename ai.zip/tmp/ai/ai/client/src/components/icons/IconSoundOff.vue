<template>
    <svg width="8" height="14" viewBox="0 0 8 14" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M0.52832 4.81509V9.63958H3.74463L7.76505 13.66V0.794678L3.74463 4.81509H0.52832Z" />
    </svg>
</template>